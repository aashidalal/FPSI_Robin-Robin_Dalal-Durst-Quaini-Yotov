addpath(genpath('C:\Users\aashi\OneDrive\Desktop\FPSI\Paraview_12'));
savepath
folder = 'C:\Users\aashi\OneDrive\Desktop\FPSI\Paraview_12';
interface=1;

%folder='Plots for pF at different times';

ThS1 = readtable('mesh_ThL.txt')

% load first line
nv = table2array(ThS1(1,1)) % number of vertices
nt = table2array(ThS1(1,2)) % number of triangles
ns = table2array(ThS1(1,3)) % number of edges

myv = table2array(ThS1(2:nv+1,1:3)) % extract all the vertices information
mys = table2array(ThS1(nv+nt+2:nv+nt+ns+1,1:3)) % extract all the edges information

mys_loc = find(mys(:,3)==interface) % find locations of all the edges with label 3
mys = mys(mys_loc,:) % extract the edges with label 3
mys_size = size(mys,1) % number of edges with label 3
% for edges, the first column is the first point of the edge, the second
% column is the second point of the edge, the third column is the label. So
% once we find out the label, then we find out the corresponding point
% coordinate, and then we can compute the length.

s_length = zeros(mys_size,1)
for i=1:mys_size
    p1 = mys(i,1) % this is the first point number of the edge
    p2 = mys(i,2)
    p1c = myv(p1,:) % this is the coordinate of the first point
    p2c = myv(p2,:)
    s_length(i)= sqrt((p1c(1)-p2c(1))^2+(p1c(2)-p2c(2))^2) % distance of two points, or length of the edge
end

sum(s_length)
xxf=cumsum(s_length)

labelf = readmatrix('ThL(N=70).csv','Range',sprintf('A2:A%d',nv+nt+ns))

loc=find(labelf==interface)
loc_start=209+1
loc_end=298+1

% pfhn70= readmatrix('ThL(N=70).csv','Range',sprintf('B%d:B%d',loc_start,loc_end))
% pfhnsub70= readmatrix('ThL2(N=70).csv','Range',sprintf('B%d:B%d',loc_start,loc_end))
% pfhnmono70= readmatrix('ThLmono(N=70).csv','Range',sprintf('B%d:B%d',loc_start,loc_end))


% pfhn140= readmatrix('ThL(N=140).csv','Range',sprintf('B%d:B%d',loc_start,loc_end))
% pfhnsub140= readmatrix('ThL2(N=140).csv','Range',sprintf('B%d:B%d',loc_start,loc_end))
% pfhnmono140= readmatrix('ThLmono(N=140).csv','Range',sprintf('B%d:B%d',loc_start,loc_end))

pfhn210= readmatrix('ThL(N=210).csv','Range',sprintf('B%d:B%d',loc_start,loc_end))
pfhnsub210= readmatrix('ThL2(N=210).csv','Range',sprintf('B%d:B%d',loc_start,loc_end))
pfhnmono210= readmatrix('ThLmono(N=210).csv','Range',sprintf('B%d:B%d',loc_start,loc_end))


fs=45;
fs1=45;
%%
blue=[0,0,1];
red=[1,0,0];

% name='pfhn70';
% title('t=0.007');
% tit='pF';
% %figure()
% hold on
% plot(xxf,pfhn70,'Color',red,'LineWidth',3,'LineStyle','--');
% axis([0 6 -500 3000]);
% plot(xxf,pfhnsub70,'Color',blue,'LineWidth',3,'LineStyle','-','Marker','pentagram');
% plot(xxf,pfhnmono70,'k-','LineWidth',3);
% hold off
% legend('Non-iterative','Iterative','Monolithic','Location','Northeast', 'FontWeight','bold'); 
% title('t=0.007');
% set(gca, 'FontSize',fs);
% xlabel('Interface(x)','FontSize',fs1,'FontWeight','bold');
% ylabel(sprintf('%s',tit),'FontSize',fs1, 'FontWeight','bold');
%saveas(gcf, sprintf('%s/%s_%d.jpg',folder,name,interface));


% name='pfhn140';
% title('t=0.014');
% tit='pF';
% %figure()
% hold on
% plot(xxf,pfhn140,'Color',red,'LineWidth',3,'LineStyle','--');
% axis([0 6 -500 3000]);
%  plot(xxf,pfhnsub140,'Color',blue,'LineWidth',3,'LineStyle','-','Marker','pentagram');
% plot(xxf,pfhnmono140,'k-','LineWidth',3);
% hold off
% legend('Non-iterative','Iterative','Monolithic','Location', 'Northeast','FontWeight','bold'); 
% title('t=0.014');
% set(gca, 'FontSize',fs);
% xlabel('Interface(x)','FontSize',fs,'FontWeight','bold');
% ylabel(sprintf('%s',tit),'FontSize',fs,'FontWeight','bold');
% %saveas(gcf, sprintf('%s/%s_%d.jpg',folder,name,interface));
% 
% %%
name='pfhn210';
title('t=0.021');
tit='pF';
%figure()
hold on
plot(xxf,pfhn210,'Color',red,'LineWidth',3,'LineStyle','--');
axis([0 6 -500 3000]);
plot(xxf,pfhnsub210,'Color',blue,'LineWidth',3,'LineStyle','-','Marker','pentagram');
plot(xxf,pfhnmono210,'k-','LineWidth',3);
hold off
legend('Non-iterative','Iterative','Monolithic','Location', 'Northeast','FontWeight','bold'); 
title('t=0.021');
set(gca, 'FontSize',fs);
xlabel('Interface(x)','FontSize',fs,'FontWeight','bold');
ylabel(sprintf('%s',tit),'FontSize',fs,'FontWeight','bold');
% %saveas(gcf, sprintf('%s/%s_%d.jpg',folder,name,interface));