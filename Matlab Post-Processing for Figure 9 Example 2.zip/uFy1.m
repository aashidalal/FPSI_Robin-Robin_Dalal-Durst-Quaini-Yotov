addpath(genpath('C:\Users\aashi\OneDrive\Desktop\FPSI\Paraview_12'));
savepath
folder = 'C:\Users\aashi\OneDrive\Desktop\FPSI\Paraview_12';
interface=1;

ThS1 = readtable('mesh_ThL.txt')

% load first line
nv = table2array(ThS1(1,1)) % number of vertices
nt = table2array(ThS1(1,2)) % number of triangles
ns = table2array(ThS1(1,3)) % number of edges

myv = table2array(ThS1(2:nv+1,1:3)) % extract all the vertices information
mys = table2array(ThS1(nv+nt+2:nv+nt+ns+1,1:3)) % extract all the edges information

mys_loc = find(mys(:,3)==interface) % find locations of all the edges with label 3
mys = mys(mys_loc,:) % extract the edges with label 3
mys_size = size(mys,1) % number of edges with label 3
% for edges, the first column is the first point of the edge, the second
% column is the second point of the edge, the third column is the label. So
% once we find out the label, then we find out the corresponding point
% coordinate, and then we can compute the length.

s_length = zeros(mys_size,1)
for i=1:mys_size
    p1 = mys(i,1) % this is the first point number of the edge
    p2 = mys(i,2)
    p1c = myv(p1,:) % this is the coordinate of the first point
    p2c = myv(p2,:)
    s_length(i)= sqrt((p1c(1)-p2c(1))^2+(p1c(2)-p2c(2))^2) % distance of two points, or length of the edge
end

sum(s_length)
xxf=cumsum(s_length)

labelf = readmatrix('ThL(N=30).csv','Range',sprintf('A2:A%d',nv+nt+ns))

loc=find(labelf==interface)
loc_start=209+1
loc_end=298+1

% ufhn70= readmatrix('ThL(N=70).csv','Range',sprintf('C%d:C%d',loc_start,loc_end))
% ufhnsub70= readmatrix('ThL2(N=70).csv','Range',sprintf('C%d:C%d',loc_start,loc_end))
% ufhnmono70= readmatrix('ThLmono(N=70).csv','Range',sprintf('C%d:C%d',loc_start,loc_end))

% ufhn140= readmatrix('ThL(N=140).csv','Range',sprintf('C%d:C%d',loc_start,loc_end))
% ufhnsub140= readmatrix('ThL2(N=140).csv','Range',sprintf('C%d:C%d',loc_start,loc_end))
% ufhnmono140= readmatrix('ThLmono(N=140).csv','Range',sprintf('C%d:C%d',loc_start,loc_end))
% % % 
ufhn210= readmatrix('ThL(N=210).csv','Range',sprintf('C%d:C%d',loc_start,loc_end))
ufhnsub210= readmatrix('ThL2(N=210).csv','Range',sprintf('C%d:C%d',loc_start,loc_end))
ufhnmono210= readmatrix('ThLmono(N=210).csv','Range',sprintf('C%d:C%d',loc_start,loc_end))



fs=45;
%%
blue=[0,0,1];
red=[1,0,0];

% name='ufhn70';
% title('t=0.007');
% tit='uF_y';
% %figure()
% hold on
% plot(xxf,ufhn70,'Color',red,'LineWidth',3,'LineStyle','--');
% plot(xxf,ufhnsub70,'Color',blue,'LineWidth',3,'LineStyle','-','Marker','pentagram');
% plot(xxf,ufhnmono70,'k-','LineWidth',3);
% hold off
% axis([0 6 -6 10]);
% legend('Non-iterative','Iterative','Monolithic','Location', 'Northeast','FontWeight','bold'); 
% title('t=0.007'); 
% set(gca, 'FontSize',fs);
% xlabel('Interface(x)','FontSize',fs,'FontWeight','bold');
% ylabel(sprintf('%s',tit),'FontSize',fs,'FontWeight','bold');
% saveas(gcf, sprintf('%s/%s_%d.jpg',folder,name,interface));

%%
% name='ufhn140';
% title('t=0.014');
% tit='uF_y';
% figure()
% hold on
% plot(xxf,ufhn140,'Color',red,'LineWidth',3,'LineStyle','--');
% plot(xxf,ufhnsub140,'Color',blue,'LineWidth',3,'LineStyle','-','Marker','pentagram');
% plot(xxf,ufhnmono140,'k-','LineWidth',3);
% hold off
% axis([0 6 -6 10]);
% legend('Non-iterative','Iterative','Monolithic','Location', 'Northeast','FontWeight','bold'); 
% title('t=0.014'); 
% set(gca, 'FontSize',fs);
% xlabel('Interface(x)','FontSize',fs,'FontWeight','bold');
% ylabel(sprintf('%s',tit),'FontSize',fs,'FontWeight','bold');
% saveas(gcf, sprintf('%s/%s_%d.jpg',folder,name,interface));
% 
% %%
name='ufhn210';
title('t=0.021');
tit='uF_y';
figure()
hold on
plot(xxf,ufhn210,'Color',red,'LineWidth',3,'LineStyle','--');
plot(xxf,ufhnsub210,'Color',blue,'LineWidth',3,'LineStyle','-','Marker','pentagram');
plot(xxf,ufhnmono210,'k-','LineWidth',3);
hold off
axis([0 6 -6 10]);
legend('Non-iterative','Iterative','Monolithic','Location', 'Northeast','FontWeight','bold'); 
title('t=0.021'); 
set(gca, 'FontSize',fs);
xlabel('Interface(x)','FontSize',fs,'FontWeight','bold');
ylabel(sprintf('%s',tit),'FontSize',fs,'FontWeight','bold');
% saveas(gcf, sprintf('%s/%s_%d.jpg',folder,name,interface));