1) bloodflow-noniter-1.edp runs the FreeFem++ code for the non-iterative algorithm for gamma=1000 to obtain the interface plots of Figure 9 on Page 31.
2) bloodflow-iter-2.edp runs the FreeFem++ code for the iterative algorithm for gamma=1000 to obtain the interface plots of Figure 9 on Page 31.
3) bloodflow-monolithic-3.edp runs the FreeFem++ code for the monolithic schme for gamma=1000 to obtain the interface plots of Figure 9 on Page 31.
4) All the csv excel files consist of values of stokes and biot variables on the interface at N=70, 140, 210 and gamma= 1000 for non-iterative, iterative, 
   and monolithic scheme.
5) pF1.m, uFy1.m, uPy1.m, etay1.m are matlab files for fluid pressure, vertical fluid velocity, vertical Darcy
   velocity, vertical structure displacement  along the interface computed by the non-iterative, iterative, and monolithic schemes at times t = 0.007,0.014,0.021 s 
   for gamma=1000.
6) iterationVec.txt consist of the iteration vector from running the iterative algorithm bloodflow-iter-2.edp and Average iterations: 30.24761905.
