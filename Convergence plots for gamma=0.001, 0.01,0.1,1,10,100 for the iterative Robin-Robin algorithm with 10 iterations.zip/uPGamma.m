fs=45;
fs1=45;
%%
blue=[0,0,1];
red=[1,0,0];
orange=[0.8500 0.3250 0.0980];
maroon=[0.6350 0.0780 0.1840];
wine=[0.4940 0.1840 0.5560];
dt = [.2 0.1 0.05 0.025 0.0125];
y1d = [2.305 1.530 0.9805 0.5849 0.3203];%Gamma=0.001
y1e = [1.729 0.9985 0.5543 0.2964 0.1544];%Gamma=0.01
y1f = [1.731 1.006 0.5604 0.2999 0.1560];%Gamma=0.1
y3a = [1.731 1.006 0.5603 0.2995 0.1554];%Gamma=1
y4a = [1.730 1.005 0.5603 0.2998 0.1560];%Gamma=10
y5a= [1.712 1.007 0.5669 0.3049 0.1581];%Gamma=100
loglog(dt, y1d,'Color',[0.4940 0.1840 0.5560],'LineWidth',3,'LineStyle','--','Marker','pentagram','MarkerSize',16);
hold on
loglog(dt, y1e,'Color',orange,'LineWidth',3,'LineStyle','--','Marker','square','MarkerSize',16);
loglog(dt, y1f,"m",'LineWidth',3,'LineStyle','--','Marker','o','MarkerSize',16);
plot(dt, y3a,"r",'LineWidth',3,'LineStyle','--','Marker','hexagram','MarkerSize',16);
plot(dt,y4a,"b",'LineWidth',3,'LineStyle','--','Marker','^','MarkerSize',16);
loglog(dt,y5a,'Color',maroon,'LineWidth',3,'LineStyle','--','Marker','diamond','MarkerSize',16);
loglog([.2 0.0125],[10.0 10.0*.0125/.2],'g-','LineWidth',3)
%hold off
%ylim([0.1 6]);
%set(gca, 'XTick',[.0125 .025 .05 .1 .2])
%set(gca,'XTick',[0 .0125 .025 .05 .1 .2], 'XTickLabel',{' ' '0.0125' '0.025' '0.05' '0.1' '0.2'})
xticks([0 .0125 .025 .05 .1 .2])
xticklabels({' ' '0.0125' '0.025' '0.05' '0.1' '0.2'})
set(gca, 'YTick', [0 0.1 1 10],'YTickLabel',{' ' '10^{-1}' '10^{0}' '10^{1}'})
legend('\gamma=0.001','\gamma=0.01','\gamma=0.1','\gamma=1','\gamma=10','\gamma=100','Slope 1','Location','northwest','NumColumns',2,'FontWeight','bold');
set(gca, 'FontSize',fs);
xlabel('\Deltat','FontSize',fs,'FontWeight','bold');
ylabel('Errors for Darcy velocity (u_p)','FontSize',fs,'FontWeight','bold');
set(gcf, 'PaperSize', [20 13], 'PaperPosition', [0 0 20 13])
