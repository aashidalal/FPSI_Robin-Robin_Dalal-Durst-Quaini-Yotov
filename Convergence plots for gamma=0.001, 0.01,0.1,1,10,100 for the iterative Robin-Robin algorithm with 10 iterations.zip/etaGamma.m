fs=45;
fs1=45;
%%
blue=[0,0,1];
red=[1,0,0];
orange=[0.8500 0.3250 0.0980];
maroon=[0.6350 0.0780 0.1840];
wine=[0.4940 0.1840 0.5560];
dt = [.2 0.1 0.05 0.025 0.0125];
y1g = [1.152 0.7429 0.4549 0.2750 0.1568];%Gamma=0.001
y1h = [1.074 0.6978 0.4359 0.2537 0.1381];%Gamma=0.01
y1i = [1.490 0.8817 0.4963 0.2682 0.1407];%Gamma=0.1
y3b = [1.512 0.8772 0.4903 0.2637 0.1373];%Gamma=1
y4b = [1.511 0.8809 0.4931 0.2655 0.1383];%Gamma=10
y5b = [1.271 0.8090 0.4589 0.2334 0.1147];%Gamma=100
loglog(dt, y1g,'Color',[0.4940 0.1840 0.5560],'LineWidth',3,'LineStyle','--','Marker','pentagram','MarkerSize',16);
hold on
loglog(dt, y1h,'Color',orange,'LineWidth',3,'LineStyle','--','Marker','square','MarkerSize',16);
loglog(dt, y1i,"m",'LineWidth',3,'LineStyle','--','Marker','o','MarkerSize',16);
plot(dt, y3b,"r",'LineWidth',3,'LineStyle','--','Marker','hexagram','MarkerSize',16);
plot(dt,y4b,"b",'LineWidth',3,'LineStyle','--','Marker','^','MarkerSize',16);
loglog(dt,y5b,'Color',maroon,'LineWidth',3,'LineStyle','--','Marker','diamond','MarkerSize',16);
loglog([.2 0.0125],[10.0 10.0*.0125/.2],'g-','LineWidth',3)
hold off
%ylim([0.1 6]);
%set(gca, 'XTick',[.0125 .025 .05 .1 .2])
%set(gca,'XTick',[0 .0125 .025 .05 .1 .2], 'XTickLabel',{' ' '0.0125' '0.025' '0.05' '0.1' '0.2'})
xticks([0 .0125 .025 .05 .1 .2])
xticklabels({' ' '0.0125' '0.025' '0.05' '0.1' '0.2'})
set(gca, 'YTick', [0 0.1 1 10],'YTickLabel',{' ' '10^{-1}' '10^{0}' '10^{1}'})
legend('\gamma=0.001','\gamma=0.01','\gamma=0.1','\gamma=1','\gamma=10','\gamma=100','Slope 1','Location','northwest','NumColumns',2,'FontWeight','bold');
set(gca, 'FontSize',fs);
xlabel('\Deltat','FontSize',fs,'FontWeight','bold');
ylabel('Errors for displacement (\eta_p)','FontSize',fs,'FontWeight','bold');
set(gcf, 'PaperSize', [20 13], 'PaperPosition', [0 0 20 13])
