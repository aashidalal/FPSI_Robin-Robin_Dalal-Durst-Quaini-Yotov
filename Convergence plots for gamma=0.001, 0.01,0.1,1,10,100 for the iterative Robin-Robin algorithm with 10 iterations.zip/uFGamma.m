fs=45;
fs1=45;
%%
blue=[0,0,1];
red=[1,0,0];
orange=[0.8500 0.3250 0.0980];
maroon=[0.6350 0.0780 0.1840];
wine=[0.4940 0.1840 0.5560];
dt = [.2 0.1 0.05 0.025 0.0125];
y1a = [0.6984 0.3920 0.2174 0.1259 0.07316];%Gamma=0.001
y1b = [0.8452 0.5077 0.2968 0.1616 0.08384];%Gamma=0.01
y1c = [1.218 0.6490 0.3349 0.1698 0.08603];%Gamma=0.1
y2 = [1.240 0.6491 0.3325 0.1676 0.08365];%Gamma=1
y3= [1.236 0.6477 0.3326 0.1681 0.08372];%Gamma=10
y4= [2.905 1.490 0.6969 0.3030 0.1259];%Gamma=100
loglog(dt, y1a,'Color',[0.4940 0.1840 0.5560],'LineWidth',3,'LineStyle','--','Marker','pentagram','MarkerSize',16);
hold on
loglog(dt, y1b,'Color',orange,'LineWidth',3,'LineStyle','--','Marker','square','MarkerSize',16);
loglog(dt, y1c,"m",'LineWidth',3,'LineStyle','--','Marker','o','MarkerSize',16);
plot(dt, y2,"r",'LineWidth',3,'LineStyle','--','Marker','hexagram','MarkerSize',16);
plot(dt,y3,"b",'LineWidth',3,'LineStyle','--','Marker','^','MarkerSize',16);
loglog(dt,y4,'Color',maroon,'LineWidth',3,'LineStyle','--','Marker','diamond','MarkerSize',16);
loglog([.2 0.0125],[5.0 5.0*.0125/.2],'g-','LineWidth',3)%slope=1
%hold off
%ylim([0.1 6]);
%set(gca, 'XTick',[.0125 .025 .05 .1 .2])
%set(gca,'XTick',[0 .0125 .025 .05 .1 .2], 'XTickLabel',{' ' '0.0125' '0.025' '0.05' '0.1' '0.2'})
xticks([0 .0125 .025 .05 .1 .2])
xticklabels({' ' '0.0125' '0.025' '0.05' '0.1' '0.2'})
set(gca, 'YTick', [.1 1 10], 'YTickLabel',{'10^{-1}' '10^0' '10^{1}'})
%set(gca, 'YTick', [1 2 3 4 5 6])
%title('Errors for u_f with Neumann boundary conditions');
legend('\gamma=0.001','\gamma=0.01','\gamma=0.1','\gamma=1','\gamma=10','\gamma=100','Slope 1','Location','northwest','NumColumns',2,'FontWeight','bold');  
set(gca, 'FontSize',fs1);
xlabel('\Deltat','FontSize',fs,'FontWeight','bold');
ylabel('Errors for fluid velocity (u_f)','FontSize',fs1,'FontWeight','bold');
set(gcf, 'PaperSize', [20 13], 'PaperPosition', [0 0 20 13])