fs=45;
fs1=45;
%%
blue=[0,0,1];
red=[1,0,0];
wine=[0.4940 0.1840 0.5560];
dt = [.2 0.1 0.05 0.025 0.0125];
%GAMMA=1
% y3 = [1.663 0.9071 0.4768 0.244 0.1247];
% y3a = [1.240 0.6491 0.3325 0.1676 0.08365];%Gamma=1
% y4= [1.233 0.6481 0.3331 0.1686 0.08473];
% y4a= [1.233 0.6481 0.3331 0.1686 0.08473];
% loglog(dt, y3,'Color',red,'LineWidth',3,'LineStyle','--');
% hold on
% plot(dt,y3a,'Color',wine,'LineWidth',3,'LineStyle','-.');
% plot(dt,y4,'Color',blue,'LineWidth',3,'LineStyle','-','Marker','pentagram','MarkerSize',16);
% plot(dt,y4a,'k-','LineWidth',3);
% loglog([.2 0.0125],[2.5 2.5*.0125/.2],'g-','LineWidth',3)
% hold off
% ylim([0.1 2]);
% set(gca, 'XTick',[.0125 .025 .05 .1 .2], 'XTickLabel',{'0.0125' '0.025' '0.05' '0.1' '0.2'})
% set(gca, 'YTick', [.1 .2 .5 1])
% %title('Errors for u_f with Neumann boundary conditions');
% legend('Non-iterative','Iterative 10','Iterative 100','Monolithic','Slope 1','Location', 'Northwest','NumColumns',2,'FontWeight','bold');  
% set(gca, 'FontSize',fs1);
% xlabel('\Deltat','FontSize',fs,'FontWeight','bold');
% ylabel('Errors for fluid velocity (u_f)','FontSize',fs1,'FontWeight','bold');
% set(gcf, 'PaperSize', [20 13], 'PaperPosition', [0 0 20 13])

%GAMMA=0.001
% y3 = [0.7025 0.4068 0.3333 0.3164 0.2905];
% y3a = [0.6984 0.3920 0.2174 0.1259 0.07316];%Gamma=0.001
% y4= [0.8381 0.5009 0.2916 0.1549 0.07216];
% y4a= [1.234 0.6480 0.3331 0.1685 0.08473];
% loglog(dt, y3,'Color',red,'LineWidth',3,'LineStyle','--');
% hold on
% plot(dt,y3a,'Color',wine,'LineWidth',3,'LineStyle','-.');
% plot(dt,y4,'Color',blue,'LineWidth',3,'LineStyle','-','Marker','pentagram','MarkerSize',16);
% plot(dt,y4a,'k-','LineWidth',3);
% loglog([.2 0.0125],[2.5 2.5*.0125/.2],'g-','LineWidth',3)
% hold off
% ylim([0.1 2]);
% set(gca, 'XTick',[.0125 .025 .05 .1 .2], 'XTickLabel',{'0.0125' '0.025' '0.05' '0.1' '0.2'})
% set(gca, 'YTick', [.1 .2 .5 1])
% %title('Errors for u_f with Neumann boundary conditions');
% legend('Non-iterative','Iterative 10','Iterative 100','Monolithic','Slope 1','Location', 'Northwest','NumColumns',2,'FontWeight','bold');  
% set(gca, 'FontSize',fs1);
% xlabel('\Deltat','FontSize',fs,'FontWeight','bold');
% ylabel('Errors for fluid velocity (u_f)','FontSize',fs1,'FontWeight','bold');
% set(gcf, 'PaperSize', [20 13], 'PaperPosition', [0 0 20 13])

%GAMMA=100.00
y3 = [17.17 13.77 9.606 5.962 3.403];
y3a= [2.905 1.490 0.6969 0.3030 0.1259];%Gamma=100
y4= [1.233 0.6481 0.3331 0.1686 0.08473];
y4a= [1.233 0.6481 0.3331 0.1686 0.08473];
loglog(dt, y3,'Color',red,'LineWidth',3,'LineStyle','--');
hold on
plot(dt,y3a,'Color',wine,'LineWidth',3,'LineStyle','-.');
plot(dt,y4,'Color',blue,'LineWidth',3,'LineStyle','-','Marker','pentagram','MarkerSize',16);
plot(dt,y4a,'k-','LineWidth',3);
loglog([.2 0.0125],[25 25*.0125/.2],'g-','LineWidth',3)
hold off
%ylim([0.1 2]);
set(gca, 'XTick',[.0125 .025 .05 .1 .2], 'XTickLabel',{'0.0125' '0.025' '0.05' '0.1' '0.2'})
set(gca, 'YTick', [.1 1 10])
%title('Errors for u_f with Neumann boundary conditions');
legend('Non-iterative','Iterative 10','Iterative 100','Monolithic','Slope 1','Location', 'Northwest','NumColumns',2,'FontWeight','bold');  
set(gca, 'FontSize',fs1);
xlabel('\Deltat','FontSize',fs,'FontWeight','bold');
ylabel('Errors for fluid velocity (u_f)','FontSize',fs1,'FontWeight','bold');
set(gcf, 'PaperSize', [20 13], 'PaperPosition', [0 0 20 13])