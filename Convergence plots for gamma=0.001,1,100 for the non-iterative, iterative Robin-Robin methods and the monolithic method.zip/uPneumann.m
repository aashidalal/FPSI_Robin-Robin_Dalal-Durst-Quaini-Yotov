fs=45;
fs1=45;
%%
blue=[0,0,1];
red=[1,0,0];
wine=[0.4940 0.1840 0.5560];
dt = [.2 0.1 0.05 0.025 0.0125];
%GAMMA=1
% y7 = [1.8 1.046 0.5825 0.3113 0.1617];
% y7a = [1.731 1.006 0.5603 0.2995 0.1554];%Gamma=1
% y8= [1.730 1.005 0.5602 0.2998 0.1559];
% y8a= [1.730 1.005 0.5602 0.2998 0.1559];
% loglog(dt, y7, 'Color',red,'LineWidth',3,'LineStyle','--');
% %loglog(dt, y5, 'g-o','LineWidth',2)
% hold on
% plot(dt,y7a,'Color',wine,'LineWidth',3,'LineStyle','-.');
% plot(dt,y8,'Color',blue,'LineWidth',3,'LineStyle','-','Marker','pentagram','MarkerSize',16);
% plot(dt,y8a,'k-','LineWidth',3);
% loglog([.2 0.0125],[2.8 2.8*.0125/.2],'g-','LineWidth',3)
% hold off
% ylim([0.1 2]);
% set(gca, 'XTick',[.0125 .025 .05 .1 .2], 'XTickLabel',{'0.0125' '0.025' '0.05' '0.1' '0.2'})
% set(gca, 'YTick', [.1 .2 .5 1])
% %title('Errors for u_p with Neumann boundary conditions');
% legend('Non-iterative','Iterative 10','Iterative 100','Monolithic','Slope 1','Location', 'Northwest','NumColumns',2,'FontWeight','bold');  
% set(gca, 'FontSize',fs1);
% xlabel('\Deltat','FontSize',fs,'FontWeight','bold');
% ylabel('Errors for Darcy velocity (u_p)','FontSize',fs,'FontWeight','bold');
% set(gcf, 'PaperSize', [20 13], 'PaperPosition', [0 0 20 13])

%GAMMA=0.001
% y7 = [2.527 1.857 1.459 1.216 1.025];
% y7a = [2.305 1.530 0.9805 0.5849 0.3203];%Gamma=0.001
% y8= [1.729 0.9988 0.5545 0.294 0.1628];
% y8a= [1.730 1.005 0.5602 0.2998 0.1559];
% loglog(dt, y7, 'Color',red,'LineWidth',3,'LineStyle','--');
% %loglog(dt, y5, 'g-o','LineWidth',2)
% hold on
% plot(dt,y7a,'Color',wine,'LineWidth',3,'LineStyle','-.');
% plot(dt,y8,'Color',blue,'LineWidth',3,'LineStyle','-','Marker','pentagram','MarkerSize',16);
% plot(dt,y8a,'k-','LineWidth',3);
% loglog([.2 0.0125],[6.0 6.0*.0125/.2],'g-','LineWidth',3)
% hold off
% %ylim([0.1 2]);
% set(gca, 'XTick',[.0125 .025 .05 .1 .2], 'XTickLabel',{'0.0125' '0.025' '0.05' '0.1' '0.2'})
% set(gca, 'YTick', [0 .1 .2 .5 1 2])
% %set(gca, 'YTick', [0 0.1 1 10],'YTickLabel',{' ' '10^{-1}' '10^{0}' '10^{1}'})
% %title('Errors for u_p with Neumann boundary conditions');
% legend('Non-iterative','Iterative 10','Iterative 100','Monolithic','Slope 1','Location', 'Northwest','NumColumns',2,'FontWeight','bold');  
% set(gca, 'FontSize',fs1);
% xlabel('\Deltat','FontSize',fs,'FontWeight','bold');
% ylabel('Errors for Darcy velocity (u_p)','FontSize',fs,'FontWeight','bold');
% set(gcf, 'PaperSize', [20 13], 'PaperPosition', [0 0 20 13])

% %GAMMA=100.00
y7 = [2.689 1.952 1.331 0.8359 0.4966];
y7a= [1.712 1.007 0.5669 0.3049 0.1581];%Gamma=100
y8= [1.730 1.005 0.5602 0.2998 0.1559];
y8a= [1.730 1.005 0.5602 0.2998 0.1559];
loglog(dt, y7, 'Color',red,'LineWidth',3,'LineStyle','--');
%loglog(dt, y5, 'g-o','LineWidth',2)
hold on
plot(dt,y7a,'Color',wine,'LineWidth',3,'LineStyle','-.');
plot(dt,y8,'Color',blue,'LineWidth',3,'LineStyle','-','Marker','pentagram','MarkerSize',16);
plot(dt,y8a,'k-','LineWidth',3);
loglog([.2 0.0125],[5.0 5.0*.0125/.2],'g-','LineWidth',3)
hold off
%ylim([0.1 2]);
set(gca, 'XTick',[.0125 .025 .05 .1 .2], 'XTickLabel',{'0.0125' '0.025' '0.05' '0.1' '0.2'})
set(gca, 'YTick', [0 .1 .2 .5 1 2])
%title('Errors for u_p with Neumann boundary conditions');
legend('Non-iterative','Iterative 10','Iterative 100','Monolithic','Slope 1','Location', 'Northwest','NumColumns',2,'FontWeight','bold');  
set(gca, 'FontSize',fs1);
xlabel('\Deltat','FontSize',fs,'FontWeight','bold');
ylabel('Errors for Darcy velocity (u_p)','FontSize',fs,'FontWeight','bold');
set(gcf, 'PaperSize', [20 13], 'PaperPosition', [0 0 20 13])
