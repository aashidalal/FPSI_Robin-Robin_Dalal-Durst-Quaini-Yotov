fs=45;
fs1=45;
%%
blue=[0,0,1];
red=[1,0,0];
wine=[0.4940 0.1840 0.5560];
dt = [.2 0.1 0.05 0.025 0.0125];
%GAMMA=1
% y11 = [1.966 1.183 0.6675 0.358 0.1868];
% y11a = [1.512 0.8772 0.4903 0.2637 0.1373];%Gamma=1
% y12= [1.52 0.8827 0.4938 0.2659 0.1388];
% y12a= [1.52 0.8827 0.4938 0.2659 0.1388];
% loglog(dt, y11, 'Color',red,'LineWidth',3,'LineStyle','--');
% hold on
% plot(dt,y11a,'Color',wine,'LineWidth',3,'LineStyle','-.');
% plot(dt,y12,'Color',blue,'LineWidth',3,'LineStyle','-','Marker','pentagram','MarkerSize',16);
% plot(dt,y12a,'k-','LineWidth',3)
% loglog([.2 0.0125],[3.2 3.2*.0125/.2],'g-','LineWidth',3)
% hold off
% ylim([0.1 2]);
% set(gca, 'XTick',[.0125 .025 .05 .1 .2], 'XTickLabel',{'0.0125' '0.025' '0.05' '0.1' '0.2'})
% set(gca, 'YTick', [.1 .2 .5 1])
% %title('Errors for \eta_p with Neumann boundary conditions');
% legend('Non-iterative','Iterative 10','Iterative 100','Monolithic','Slope 1','Location', 'Northwest','NumColumns',2,'FontWeight','bold');  
% set(gca, 'FontSize',fs1);
% xlabel('\Deltat','FontSize',fs,'FontWeight','bold');
% ylabel('Errors for displacement (\eta_p)','FontSize',fs,'FontWeight','bold');
% set(gcf, 'PaperSize', [20 13], 'PaperPosition', [0 0 20 13])

%GAMMA=0.001
% y11 = [1.207 0.8108 0.5595 0.4194 0.3343];
% y11a = [1.152 0.7429 0.4549 0.2750 0.1568];%Gamma=0.001
% y12= [1.070 0.6808 0.4237 0.2405 0.1279];
% y12a= [1.52 0.8827 0.4938 0.2659 0.1388];
% loglog(dt, y11, 'Color',red,'LineWidth',3,'LineStyle','--');
% hold on
% plot(dt,y11a,'Color',wine,'LineWidth',3,'LineStyle','-.');
% plot(dt,y12,'Color',blue,'LineWidth',3,'LineStyle','-','Marker','pentagram','MarkerSize',16);
% plot(dt,y12a,'k-','LineWidth',3)
% loglog([.2 0.0125],[3.0 3.0*.0125/.2],'g-','LineWidth',3)
% hold off
% ylim([0.1 2]);
% set(gca, 'XTick',[.0125 .025 .05 .1 .2], 'XTickLabel',{'0.0125' '0.025' '0.05' '0.1' '0.2'})
% set(gca, 'YTick', [.1 .2 .5 1])
% %title('Errors for \eta_p with Neumann boundary conditions');
% legend('Non-iterative','Iterative 10','Iterative 100','Monolithic','Slope 1','Location', 'Northwest','NumColumns',2,'FontWeight','bold');  
% set(gca, 'FontSize',fs1);
% xlabel('\Deltat','FontSize',fs,'FontWeight','bold');
% ylabel('Errors for displacement (\eta_p)','FontSize',fs,'FontWeight','bold');
% set(gcf, 'PaperSize', [20 13], 'PaperPosition', [0 0 20 13])

% %GAMMA=100.00
y11 = [4.526 3.879 2.990 2.093 1.361];
y11a = [1.271 0.8090 0.4589 0.2334 0.1147];%Gamma=100
y12= [1.513 0.8817 0.4931 0.2653 0.1382];
y12a= [1.52 0.8826 0.4937 0.2659 0.1388];
loglog(dt, y11, 'Color',red,'LineWidth',3,'LineStyle','--');
hold on
plot(dt,y11a,'Color',wine,'LineWidth',3,'LineStyle','-.');
plot(dt,y12,'Color',blue,'LineWidth',3,'LineStyle','-','Marker','pentagram','MarkerSize',16);
plot(dt,y12a,'k-','LineWidth',3)
loglog([.2 0.0125],[25.0 25.0*.0125/.2],'g-','LineWidth',3)
hold off
%ylim([0.1 2]);
set(gca, 'XTick',[.0125 .025 .05 .1 .2], 'XTickLabel',{'0.0125' '0.025' '0.05' '0.1' '0.2'})
set(gca, 'YTick', [0 0.1 1 10],'YTickLabel',{' ' '10^{-1}' '10^{0}' '10^{1}'})
%title('Errors for \eta_p with Neumann boundary conditions');
legend('Non-iterative','Iterative 10','Iterative 100','Monolithic','Slope 1','Location', 'Northwest','NumColumns',2,'FontWeight','bold');  
set(gca, 'FontSize',fs1);
xlabel('\Deltat','FontSize',fs,'FontWeight','bold');
ylabel('Errors for displacement (\eta_p)','FontSize',fs,'FontWeight','bold');
set(gcf, 'PaperSize', [20 13], 'PaperPosition', [0 0 20 13])
