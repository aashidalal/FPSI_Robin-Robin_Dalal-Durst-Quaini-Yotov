addpath(genpath('C:\Users\aashi\OneDrive\Desktop\FPSI\Paraview_15'));
savepath
folder = 'C:\Users\aashi\OneDrive\Desktop\FPSI\Paraview_15';
interface=3;

%folder='Plots for uPy at different times';

ThS1 = readtable('mesh_ThP.txt')

% load first line
nv = table2array(ThS1(1,1)) % number of vertices
nt = table2array(ThS1(1,2)) % number of triangles
ns = table2array(ThS1(1,3)) % number of edges

myv = table2array(ThS1(2:nv+1,1:3)) % extract all the vertices information
mys = table2array(ThS1(nv+nt+2:nv+nt+ns+1,1:3)) % extract all the edges information

mys_loc = find(mys(:,3)==interface) % find locations of all the edges with label 3
mys = mys(mys_loc,:) % extract the edges with label 3
mys_size = size(mys,1) % number of edges with label 3
% for edges, the first column is the first point of the edge, the second
% column is the second point of the edge, the third column is the label. So
% once we find out the label, then we find out the corresponding point
% coordinate, and then we can compute the length.

s_length = zeros(mys_size,1)
for i=1:mys_size
    p1 = mys(i,1) % this is the first point number of the edge
    p2 = mys(i,2)
    p1c = myv(p1,:) % this is the coordinate of the first point
    p2c = myv(p2,:)
    s_length(i)= sqrt((p1c(1)-p2c(1))^2+(p1c(2)-p2c(2))^2) % distance of two points, or length of the edge
end

sum(s_length)
xxf=cumsum(s_length)

labelf = readmatrix('Biot(Gamma=100,N=70).csv','Range',sprintf('A2:A%d',nv+nt+ns))

loc=find(labelf==interface)
loc_start=loc(1)+1
loc_end=loc(end)+1
% up70hn10= readmatrix('Biot(Gamma=10,N=70).csv','Range',sprintf('B%d:B%d',loc_start,loc_end))
% up70hn100= readmatrix('Biot(Gamma=100,N=70).csv','Range',sprintf('B%d:B%d',loc_start,loc_end))
% up70hn500= readmatrix('Biot(Gamma=500,N=70).csv','Range',sprintf('B%d:B%d',loc_start,loc_end))
% up70hn1000= readmatrix('Biot(Gamma=1000,N=70).csv','Range',sprintf('B%d:B%d',loc_start,loc_end))
% up70hn2000= readmatrix('Biot(Gamma=2000,N=70).csv','Range',sprintf('B%d:B%d',loc_start,loc_end))

up140hn10= readmatrix('Biot(Gamma=10,N=140).csv','Range',sprintf('B%d:B%d',loc_start,loc_end))
up140hn100= readmatrix('Biot(Gamma=100,N=140).csv','Range',sprintf('B%d:B%d',loc_start,loc_end))
up140hn500= readmatrix('Biot(Gamma=500,N=140).csv','Range',sprintf('B%d:B%d',loc_start,loc_end))
up140hn1000= readmatrix('Biot(Gamma=1000,N=140).csv','Range',sprintf('B%d:B%d',loc_start,loc_end))
up140hn2000= readmatrix('Biot(Gamma=2000,N=140).csv','Range',sprintf('B%d:B%d',loc_start,loc_end))
% % 
up210hn10= readmatrix('Biot(Gamma=10,N=210).csv','Range',sprintf('B%d:B%d',loc_start,loc_end))
up210hn100= readmatrix('Biot(Gamma=100,N=210).csv','Range',sprintf('B%d:B%d',loc_start,loc_end))
up210hn500= readmatrix('Biot(Gamma=500,N=210).csv','Range',sprintf('B%d:B%d',loc_start,loc_end))
up210hn1000= readmatrix('Biot(Gamma=1000,N=210).csv','Range',sprintf('B%d:B%d',loc_start,loc_end))
up210hn2000= readmatrix('Biot(Gamma=2000,N=210).csv','Range',sprintf('B%d:B%d',loc_start,loc_end))

fs=45;
%%
red=[1,0,0];
maroon=[0.6350 0.0780 0.1840];
orange=[0.8500 0.3250 0.0980];
mustard=[0.9290 0.6940 0.1250];
blue=[0 0.4470 0.7410];
gr=[0.4660 0.6740 0.1880];
purple=[0.4940 0.1840 0.5560];
% name='uphn70';
% title('t=0.007');
% tit='uP_y';
% % %figure()
% hold on
% plot(xxf,up70hn10,'Color',purple,'LineWidth',3,'LineStyle','--','Marker','o');
% plot(xxf,up70hn100,'Color',blue,'LineWidth',3,'LineStyle',':');
% % axis([0 6 -500 3000]);
% plot(xxf,up70hn500,'Color',orange,'LineWidth',3,'LineStyle','-.');
% plot(xxf,up70hn1000,'Color',maroon,'LineWidth',3,'LineStyle','-');
% plot(xxf,up70hn2000,'Color',mustard,'LineWidth',3,'LineStyle','--');
% hold off
% legend('\gamma=10','\gamma=100','\gamma=500','\gamma=1000','\gamma=2000','Location','Northeast','NumColumns',2, 'FontWeight','bold'); 
% title('t=0.007');
% set(gca, 'FontSize',fs);
% xlabel('Interface(x)','FontSize',fs1,'FontWeight','bold');
% ylabel(sprintf('%s',tit),'FontSize',fs1, 'FontWeight','bold');
% set(gcf, 'PaperSize', [20 13], 'PaperPosition', [0 0 20 13])

% name='uphn140';
% title('t=0.014');
% tit='uP_y';
% % %figure()
% hold on
% plot(xxf,up140hn10,'Color',purple,'LineWidth',3,'LineStyle','--','Marker','o');
% plot(xxf,up140hn100,'Color',blue,'LineWidth',3,'LineStyle',':');
% % axis([0 6 -500 3000]);
% plot(xxf,up140hn500,'Color',orange,'LineWidth',3,'LineStyle','-.');
% plot(xxf,up140hn1000,'Color',maroon,'LineWidth',3,'LineStyle','-');
% plot(xxf,up140hn2000,'Color',mustard,'LineWidth',3,'LineStyle','--');
% hold off
% legend('\gamma=10','\gamma=100','\gamma=500','\gamma=1000','\gamma=2000','Location','Northeast','NumColumns',2, 'FontWeight','bold'); 
% title('t=0.014');
% set(gca, 'FontSize',fs);
% xlabel('Interface(x)','FontSize',fs1,'FontWeight','bold');
% ylabel(sprintf('%s',tit),'FontSize',fs1, 'FontWeight','bold');
% set(gcf, 'PaperSize', [20 13], 'PaperPosition', [0 0 20 13])

% 
% %%

name='uphn210';
title('t=0.021');
tit='uP_y';
% %figure()
hold on
plot(xxf,up210hn10,'Color',purple,'LineWidth',3,'LineStyle','--','Marker','o');
plot(xxf,up210hn100,'Color',blue,'LineWidth',3,'LineStyle','--');
% axis([0 6 -500 3000]);
plot(xxf,up210hn500,'Color',orange,'LineWidth',3,'LineStyle','-.');
plot(xxf,up210hn1000,'Color',maroon,'LineWidth',3,'LineStyle','-');
plot(xxf,up210hn2000,'Color',mustard,'LineWidth',3,'LineStyle','--');
hold off
legend('\gamma=10','\gamma=100','\gamma=500','\gamma=1000','\gamma=2000','Location','Northeast','NumColumns',2, 'FontWeight','bold'); 
title('t=0.021');
set(gca, 'FontSize',fs);
xlabel('Interface(x)','FontSize',fs1,'FontWeight','bold');
ylabel(sprintf('%s',tit),'FontSize',fs1, 'FontWeight','bold');
% set(gcf, 'PaperSize', [20 13], 'PaperPosition', [0 0 20 13])
