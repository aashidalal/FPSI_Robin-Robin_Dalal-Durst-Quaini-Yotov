fs=45;
fs1=45;
%%
blue=[0,0,1];
red=[1,0,0];
orange=[0.8500 0.3250 0.0980];
maroon=[0.6350 0.0780 0.1840];
wine=[0.4940 0.1840 0.5560];
dt = [.2 0.1 0.05 0.025 0.0125];
y1d = [2.527 1.857 1.459 1.216 1.025];
y1e = [2.309 1.528 0.9781 0.5871 0.327];
y1f = [1.737 1.004 0.5586 0.2997 0.1563];
y3a = [1.8 1.046 0.5825 0.3113 0.1617];
y4a = [1.716 1.01 0.5688 0.3067 0.1603];
y5a= [2.689 1.952 1.331 0.8359 0.4966];
loglog(dt, y1d,'Color',[0.4940 0.1840 0.5560],'LineWidth',3,'LineStyle','--','Marker','pentagram','MarkerSize',16);
hold on
loglog(dt, y1e,'Color',orange,'LineWidth',3,'LineStyle','--','Marker','square','MarkerSize',16);
loglog(dt, y1f,"m",'LineWidth',3,'LineStyle','--','Marker','o','MarkerSize',16);
plot(dt, y3a,"r",'LineWidth',3,'LineStyle','--','Marker','hexagram','MarkerSize',16);
plot(dt,y4a,"b",'LineWidth',3,'LineStyle','--','Marker','^','MarkerSize',16);
loglog(dt,y5a,'Color',maroon,'LineWidth',3,'LineStyle','--','Marker','diamond','MarkerSize',16);
loglog([.2 0.0125],[25 25*.0125/.2],'g-','LineWidth',3)
%hold off
%ylim([0.1 6]);
%set(gca, 'XTick',[.0125 .025 .05 .1 .2])
%set(gca,'XTick',[0 .0125 .025 .05 .1 .2], 'XTickLabel',{' ' '0.0125' '0.025' '0.05' '0.1' '0.2'})
xticks([0 .0125 .025 .05 .1 .2])
xticklabels({' ' '0.0125' '0.025' '0.05' '0.1' '0.2'})
set(gca, 'YTick', [0 0.1 1 10],'YTickLabel',{' ' '10^{-1}' '10^{0}' '10^{1}'})
legend('\gamma=0.001','\gamma=0.01','\gamma=0.1','\gamma=1','\gamma=10','\gamma=100','Slope 1','Location','northwest','NumColumns',2,'FontWeight','bold');
set(gca, 'FontSize',fs);
xlabel('\Deltat','FontSize',fs,'FontWeight','bold');
ylabel('Errors for Darcy velocity (u_p)','FontSize',fs,'FontWeight','bold');
set(gcf, 'PaperSize', [20 13], 'PaperPosition', [0 0 20 13])
