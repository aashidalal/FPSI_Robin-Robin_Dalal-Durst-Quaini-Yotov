fs=45;
fs1=45;
%%
blue=[0,0,1];
red=[1,0,0];
orange=[0.8500 0.3250 0.0980];
maroon=[0.6350 0.0780 0.1840];
wine=[0.4940 0.1840 0.5560];
dt = [.2 0.1 0.05 0.025 0.0125];
y1g = [1.207 0.8108 0.5595 0.4194 0.3343];
y1h = [1.183 0.7637 0.4761 0.2922 0.1751];
y1i = [1.316 0.9003 0.5798 0.3433 0.1885];
y3b = [1.966 1.183 0.6675 0.358 0.1868];
y4b = [1.446 0.9742 0.6027 0.3409 0.182];
y5b = [4.526 3.879 2.99 2.093 1.361];
loglog(dt, y1g,'Color',[0.4940 0.1840 0.5560],'LineWidth',3,'LineStyle','--','Marker','pentagram','MarkerSize',16);
hold on
loglog(dt, y1h,'Color',orange,'LineWidth',3,'LineStyle','--','Marker','square','MarkerSize',16);
loglog(dt, y1i,"m",'LineWidth',3,'LineStyle','--','Marker','o','MarkerSize',16);
plot(dt, y3b,"r",'LineWidth',3,'LineStyle','--','Marker','hexagram','MarkerSize',16);
plot(dt,y4b,"b",'LineWidth',3,'LineStyle','--','Marker','^','MarkerSize',16);
loglog(dt,y5b,'Color',maroon,'LineWidth',3,'LineStyle','--','Marker','diamond','MarkerSize',16);
loglog([.2 0.0125],[25 25*.0125/.2],'g-','LineWidth',3)
hold off
%ylim([0.1 6]);
%set(gca, 'XTick',[.0125 .025 .05 .1 .2])
%set(gca,'XTick',[0 .0125 .025 .05 .1 .2], 'XTickLabel',{' ' '0.0125' '0.025' '0.05' '0.1' '0.2'})
xticks([0 .0125 .025 .05 .1 .2])
xticklabels({' ' '0.0125' '0.025' '0.05' '0.1' '0.2'})
set(gca, 'YTick', [0 0.1 1 10],'YTickLabel',{' ' '10^{-1}' '10^{0}' '10^{1}'})
legend('\gamma=0.001','\gamma=0.01','\gamma=0.1','\gamma=1','\gamma=10','\gamma=100','Slope 1','Location','northwest','NumColumns',2,'FontWeight','bold');
set(gca, 'FontSize',fs);
xlabel('\Deltat','FontSize',fs,'FontWeight','bold');
ylabel('Errors for displacement (\eta_p)','FontSize',fs,'FontWeight','bold');
set(gcf, 'PaperSize', [20 13], 'PaperPosition', [0 0 20 13])
